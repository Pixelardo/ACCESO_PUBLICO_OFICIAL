-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-05-2024 a las 22:12:08
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administradores`
--

CREATE TABLE `administradores` (
  `id_admin` int(11) NOT NULL,
  `nombre_admin` varchar(100) DEFAULT NULL,
  `telefono_admin` varchar(20) DEFAULT NULL,
  `correo_admin` varchar(100) DEFAULT NULL,
  `contraseña_admin` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `administradores`
--

INSERT INTO `administradores` (`id_admin`, `nombre_admin`, `telefono_admin`, `correo_admin`, `contraseña_admin`) VALUES
(1, 'Admin1', '123456789', 'admin1@gmail.com', 'contraseña1'),
(2, 'Admin2', '987654321', 'admin2@gmail.com', 'contraseña2'),
(3, 'Admin3', '555555555', 'admin3@gmail.com', 'contraseña3'),
(4, 'Admin4', '123456789', 'admin1@example.com', 'admin123'),
(5, 'Admin5', '987654321', 'admin2@example.com', 'admin456'),
(6, 'Admin6', '111222333', 'admin3@example.com', 'admin789'),
(7, 'Admin7', '444555666', 'admin4@example.com', 'admin987'),
(8, 'Admin8', '777888999', 'admin5@example.com', 'admin654'),
(9, 'Admin9', '666777888', 'admin6@example.com', 'admin321'),
(10, 'Admin10', '222333444', 'admin7@example.com', 'admin246'),
(11, 'Admin11', '999888777', 'admin8@example.com', 'admin135'),
(12, 'Admin12', '888999888', 'admin9@example.com', 'admin864'),
(13, 'Admin13', '555666777', 'admin10@example.com', 'admin975');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `genero`
--

CREATE TABLE `genero` (
  `id_genero` int(11) NOT NULL,
  `nombre_genero` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `genero`
--

INSERT INTO `genero` (`id_genero`, `nombre_genero`) VALUES
(1, 'Historia y Geografía'),
(2, 'Infantil'),
(3, 'Fantasía');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `intereses`
--

CREATE TABLE `intereses` (
  `id_interes` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_subgenero` int(11) DEFAULT NULL,
  `nombre_interes` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `intereses`
--

INSERT INTO `intereses` (`id_interes`, `id_usuario`, `id_subgenero`, `nombre_interes`) VALUES
(1, 1, 1, 'Fantasía Épica'),
(2, 2, 2, 'Aventuras de Piratas'),
(3, 3, 3, 'Aventuras Espaciales'),
(4, 4, 4, 'Aventuras de Misterio'),
(5, 5, 5, 'Aventuras de Viaje en el Tiempo'),
(6, 6, 6, 'Geografía Mundial'),
(7, 7, 7, 'Geografía Europea'),
(8, 8, 8, 'Historia Antigua'),
(9, 9, 9, 'Historia Contemporánea'),
(10, 10, 10, 'Fantasía Urbana'),
(127, 10, 1, 'Fantasía Épica'),
(128, 12, 2, 'Aventuras de Piratas'),
(129, 13, 3, 'Aventuras Espaciales'),
(130, 14, 4, 'Aventuras de Misterio'),
(131, 15, 5, 'Aventuras de Viaje en el Tiempo'),
(132, 16, 6, 'Geografía Mundial'),
(133, 17, 7, 'Geografía Europea'),
(134, 18, 8, 'Historia Antigua'),
(135, 19, 9, 'Historia Contemporánea'),
(136, 20, 10, 'Fantasía Urbana'),
(137, 21, 1, 'Fantasía Épica'),
(138, 22, 2, 'Aventuras de Piratas'),
(139, 23, 3, 'Aventuras Espaciales'),
(140, 24, 4, 'Aventuras de Misterio'),
(141, 25, 5, 'Aventuras de Viaje en el Tiempo'),
(142, 26, 6, 'Geografía Mundial'),
(143, 27, 7, 'Geografía Europea'),
(144, 28, 8, 'Historia Antigua'),
(145, 29, 9, 'Historia Contemporánea'),
(146, 30, 10, 'Fantasía Urbana');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `ISBN` varchar(50) NOT NULL,
  `Titulo` varchar(100) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `formato` varchar(50) DEFAULT NULL,
  `autor` varchar(100) DEFAULT NULL,
  `idioma` varchar(50) DEFAULT NULL,
  `disponibilidad` tinyint(1) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `id_subgenero` int(11) DEFAULT NULL,
  `id_vendedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`ISBN`, `Titulo`, `descripcion`, `formato`, `autor`, `idioma`, `disponibilidad`, `precio`, `fecha_creacion`, `id_subgenero`, `id_vendedor`) VALUES
('9780061120084', 'Orgullo y prejuicio', 'Orgullo y prejuicio es una novela de Jane Austen que sigue la vida de la protagonista Elizabeth Bennet mientras lidia con cuestiones de matrimonio, moralidad y prejuicio social en la Inglaterra del siglo XIX.', 'Tapa blanda', 'Jane Austen', 'Inglés', 1, '15990.00', '2022-09-02 09:51:44', 10, 8),
('9780061122415', 'To Kill a Mockingbird', 'To Kill a Mockingbird is a novel by Harper Lee that addresses the issues of racism and injustice in the American South through the eyes of a young girl named Scout Finch.', 'Mass Market Paperback', 'Harper Lee', 'Inglés', 1, '14990.00', '2023-04-12 06:01:04', 9, 10),
('9780062316097', 'The Martian', 'The Martian is a science fiction novel written by Andy Weir that follows astronaut Mark Watney as he becomes stranded on Mars and must use his ingenuity to survive.', 'Paperback', 'Andy Weir', 'Inglés', 0, '17990.00', '2022-09-11 08:51:34', 3, 1),
('9780140188542', 'Drácula', 'Drácula es una novela de Bram Stoker que sigue la historia del Conde Drácula y su intento de trasladarse de Transilvania a Inglaterra para encontrar nuevas víctimas y propagar la no-muerte entre la sociedad victoriana.', 'Tapa blanda', 'Bram Stoker', 'Español', 1, '14990.00', '2023-03-04 18:27:26', 7, 5),
('9780140441000', 'La Odisea', 'La Odisea es una epopeya griega atribuida a Homero que narra el viaje de Ulises de regreso a casa después de la guerra de Troya.', 'Tapa dura', 'Homero', 'Español', 1, '13990.00', '2024-11-13 21:56:29', 1, 8),
('9780141182605', 'The Catcher in the Rye', 'The Catcher in the Rye is a novel by J.D. Salinger that follows the story of Holden Caulfield, a disaffected teenager who wanders through New York City grappling with themes of identity, alienation, and the phoniness of adult society.', 'Paperback', 'J.D. Salinger', 'Inglés', 1, '12990.00', '2022-01-31 08:23:30', 6, 12),
('9780141439556', 'Frankenstein', 'Frankenstein; or, The Modern Prometheus is a novel by Mary Shelley that tells the story of Victor Frankenstein, a young scientist who creates a grotesque creature in an unorthodox scientific experiment.', 'Paperback', 'Mary Shelley', 'Inglés', 1, '10990.00', '2024-07-19 15:07:28', 7, 2),
('9780141439587', 'Frankenstein', 'Frankenstein es una novela escrita por Mary Shelley que cuenta la historia del científico Victor Frankenstein y su monstruosa creación.', 'Tapa blanda', 'Mary Shelley', 'Inglés', 1, '11990.00', '2022-10-01 17:24:16', 10, 4),
('9780141439610', 'Frankenstein', 'Frankenstein; or, The Modern Prometheus, is a gothic novel by Mary Shelley that tells the story of Victor Frankenstein, a young scientist who creates a grotesque creature in an unorthodox scientific experiment.', 'Paperback', 'Mary Shelley', 'Inglés', 1, '15990.00', '2023-02-07 02:02:26', 1, 6),
('9780142437230', 'Jane Eyre', 'Jane Eyre es una novela de Charlotte Brontë que narra la historia de Jane Eyre, una joven institutriz, mientras lidia con cuestiones de amor, moralidad y autonomía en la Inglaterra victoriana.', 'Tapa blanda', 'Charlotte Brontë', 'Inglés', 1, '12990.00', '2023-06-07 21:39:21', 10, 4),
('9780143034916', 'The Hobbit', 'The Hobbit, or There and Back Again, is a fantasy novel by J.R.R. Tolkien that follows the journey of the hobbit Bilbo Baggins as he accompanies a group of dwarves on a quest to reclaim their homeland and treasure from the dragon Smaug.', 'Mass Market Paperback', 'J.R.R. Tolkien', 'Inglés', 1, '14990.00', '2022-07-01 20:38:12', 1, 6),
('9780143039959', 'The Great Gatsby', 'The Great Gatsby is a novel by F. Scott Fitzgerald set in the Roaring Twenties that follows the story of Jay Gatsby, a mysterious millionaire, and his obsession with Daisy Buchanan.', 'Paperback', 'F. Scott Fitzgerald', 'Inglés', 0, '17990.00', '2024-03-16 14:30:06', 10, 2),
('9780143105959', '1984', '1984 is a dystopian novel by George Orwell that explores themes of totalitarianism, surveillance, and government control. It follows the story of Winston Smith, a low-ranking member of the ruling Party, as he rebels against the oppressive regime.', 'Mass Market Paperback', 'George Orwell', 'Inglés', 0, '15990.00', '2023-04-24 08:16:04', 8, 13),
('9780143106233', 'Crimen y castigo', 'Crimen y castigo es una novela de Fiódor Dostoyevski que sigue la historia de Rodion Raskólnikov, un estudiante que comete un asesinato y lidia con las consecuencias.', 'Tapa blanda', 'Fiódor Dostoyevski', 'Español', 1, '13990.00', '2022-03-29 05:08:36', 4, 2),
('9780143111596', 'El retrato de Dorian Gray', 'El retrato de Dorian Gray es una novela de Oscar Wilde que explora los temas de la vanidad, el narcisismo y la moralidad a través de la historia de un joven cuyo retrato envejece mientras él permanece joven y bello.', 'Tapa blanda', 'Oscar Wilde', 'Español', 1, '16990.00', '2022-11-13 06:17:27', 7, 10),
('9780143123628', 'Inferno', 'Inferno is a mystery thriller novel written by Dan Brown that follows Harvard professor Robert Langdon as he tries to unravel a mystery involving a deadly virus and a conspiracy tied to Dante\'s Inferno.', 'Paperback', 'Dan Brown', 'Inglés', 1, '14990.00', '2023-08-14 01:04:55', 4, 9),
('9780307277676', 'The Catcher in the Rye', 'The Catcher in the Rye is a novel by J.D. Salinger that follows the story of Holden Caulfield, a young man struggling with adolescence and societal expectations.', 'Paperback', 'J.D. Salinger', 'Inglés', 1, '12990.00', '2023-06-16 01:40:52', 6, 3),
('9780307476078', 'The Help', 'The Help is a historical fiction novel written by Kathryn Stockett that explores the lives of black maids working in white households in Jackson, Mississippi during the early 1960s.', 'Paperback', 'Kathryn Stockett', 'Inglés', 0, '14990.00', '2022-02-26 19:30:46', 9, 13),
('9780307887436', 'The Martian', 'The Martian is a science fiction novel by Andy Weir that tells the story of an astronaut, Mark Watney, who is stranded on Mars and must use his ingenuity to survive.', 'Paperback', 'Andy Weir', 'Inglés', 0, '12990.00', '2023-03-10 04:03:21', 3, 2),
('9780307887443', 'The Hobbit', 'The Hobbit, or There and Back Again, is a fantasy novel by J.R.R. Tolkien that follows the journey of Bilbo Baggins, a hobbit who embarks on an adventure to reclaim a treasure guarded by the dragon Smaug.', 'Mass Market Paperback', 'J.R.R. Tolkien', 'Inglés', 1, '12990.00', '2022-03-18 04:13:10', 1, 6),
('9780316769532', 'To Kill a Mockingbird', 'To Kill a Mockingbird is a novel by Harper Lee that explores themes of racial injustice and moral growth through the eyes of a young girl named Scout Finch in the 1930s American South.', 'Paperback', 'Harper Lee', 'Inglés', 0, '13990.00', '2022-09-01 17:27:42', 3, 3),
('9780345342966', 'Jurassic Park', 'Jurassic Park is a science fiction novel written by Michael Crichton that tells the story of a theme park populated by genetically engineered dinosaurs and the disastrous events that occur when the creatures escape their enclosures.', 'Mass Market Paperback', 'Michael Crichton', 'Inglés', 1, '12990.00', '2024-01-03 11:05:43', 3, 5),
('9780345391802', 'The Martian Chronicles', 'The Martian Chronicles is a science fiction short story collection written by Ray Bradbury that chronicles the colonization of Mars by humans and the conflicts that arise between them and the native Martians.', 'Mass Market Paperback', 'Ray Bradbury', 'Inglés', 1, '14990.00', '2023-06-08 09:21:11', 3, 4),
('9780345470716', 'Ready Player One', 'Ready Player One is a science fiction novel written by Ernest Cline that takes place in a dystopian future where people escape their harsh reality by immersing themselves in a virtual reality world called the OASIS.', 'Paperback', 'Ernest Cline', 'Inglés', 1, '13990.00', '2023-04-26 18:42:53', 3, 1),
('9780385537858', 'The Girl on the Train', 'The Girl on the Train is a psychological thriller novel written by Paula Hawkins that follows the lives of three women, intertwined by a series of events surrounding a murder investigation.', 'Hardcover', 'Paula Hawkins', 'Inglés', 1, '16990.00', '2023-04-24 11:08:56', 4, 6),
('9780451524935', 'Moby-Dick', 'Moby-Dick es una novela escrita por Herman Melville que narra la obsesión del capitán Ahab por vengarse de un gran cachalote blanco.', 'Tapa blanda', 'Herman Melville', 'Inglés', 1, '10990.00', '2023-10-07 23:37:42', 5, 4),
('9780525478812', 'Harry Potter and the Philosopher\'s Stone', 'Harry Potter and the Philosopher\'s Stone is the first book in the Harry Potter series by J.K. Rowling. It follows the journey of a young wizard named Harry Potter as he discovers his magical heritage and attends Hogwarts School of Witchcraft and Wizardry.', 'Hardcover', 'J.K. Rowling', 'Inglés', 1, '15990.00', '2024-04-13 12:18:48', 1, 3),
('9780545010221', 'Harry Potter y las Reliquias de la Muerte', 'La novela final de la serie de Harry Potter', 'Tapa dura', 'J.K. Rowling', 'Español', 1, '10.99', '2023-03-12 16:52:42', 1, 9),
('9780547928227', 'The Hunger Games', 'The Hunger Games is a dystopian novel written by Suzanne Collins that follows protagonist Katniss Everdeen as she navigates a deadly televised competition in a post-apocalyptic society.', 'Hardcover', 'Suzanne Collins', 'Inglés', 1, '12990.00', '2024-04-05 01:42:47', 1, 4),
('9780590353427', 'Harry Potter and the Philosopher\'s Stone', 'Harry Potter and the Philosopher\'s Stone is the first book in the Harry Potter series written by J.K. Rowling, which follows the adventures of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley as they attend Hogwarts.', 'Paperback', 'J.K. Rowling', 'Inglés', 1, '15990.00', '2023-08-30 01:54:07', 1, 6),
('9780807281918', 'Eragon', 'Eragon is a fantasy novel by Christopher Paolini that follows the story of a young farm boy named Eragon who discovers a dragon egg and becomes embroiled in a battle against an evil king.', 'Audiobook', 'Christopher Paolini', 'Inglés', 0, '17990.00', '2022-05-09 01:55:00', 1, 10),
('9781400032716', '1984', '1984 is a dystopian novel by George Orwell that explores themes of totalitarianism, surveillance, and government oppression.', 'Paperback', 'George Orwell', 'Inglés', 0, '16990.00', '2022-03-27 21:40:13', 10, 8),
('9781501173219', 'Ready Player One', 'Ready Player One is a science fiction novel by Ernest Cline set in a dystopian future where people escape their harsh reality by entering a virtual reality world called the OASIS. The story follows Wade Watts as he embarks on a quest within the OASIS to find an Easter egg left by its creator.', 'Paperback', 'Ernest Cline', 'Inglés', 1, '13990.00', '2024-03-06 11:43:47', 10, 9),
('9786073102210', '1984', '1984 es una novela de George Orwell publicada en 1949 que narra una historia distópica y totalitaria.', 'Tapa blanda', 'George Orwell', 'Español', 1, '14990.00', '2022-09-07 02:11:18', 4, 7),
('9788401334128', 'El Señor de los Anillos: La Comunidad del Anillo', 'La Comunidad del Anillo es el primer libro de la trilogía de El Señor de los Anillos escrita por J.R.R. Tolkien, que sigue la búsqueda de un grupo de personajes para destruir un poderoso anillo y derrotar al Señor Oscuro Sauron.', 'Tapa blanda', 'J.R.R. Tolkien', 'Español', 1, '16990.00', '2022-05-22 21:53:35', 1, 10),
('9788401352452', 'El Silmarillion', 'El Silmarillion es una colección de relatos y mitos escrita por J.R.R. Tolkien que narra la historia del universo ficticio de la Tierra Media, desde su creación hasta eventos que preceden a El Señor de los Anillos.', 'Tapa dura', 'J.R.R. Tolkien', 'Español', 0, '13990.00', '2022-10-31 06:44:26', 1, 3),
('9788408167084', 'Harry Potter y la Piedra Filosofal', 'Harry Potter y la Piedra Filosofal es el primer libro de la serie Harry Potter escrita por J.K. Rowling, que cuenta la historia del joven mago Harry Potter mientras asiste a la escuela de magia y hechicería de Hogwarts.', 'Tapa blanda', 'J.K. Rowling', 'Español', 1, '15990.00', '2022-10-28 04:01:23', 1, 6),
('9788408212893', 'El Principito', 'El Principito es un relato corto y la obra más famosa del escritor y aviador francés Antoine de Saint-Exupéry.', 'Tapa dura', 'Antoine de Saint-Exupéry', 'Español', 1, '12000.00', '2023-03-01 07:55:21', 6, 11),
('9788415139220', 'Las Aventuras de Sherlock Holmes', 'Las Aventuras de Sherlock Holmes es una colección de cuentos de misterio escritos por Sir Arthur Conan Doyle que siguen al famoso detective Sherlock Holmes y su compañero el Dr. Watson mientras resuelven casos intrigantes.', 'Tapa blanda', 'Arthur Conan Doyle', 'Español', 1, '11990.00', '2022-12-19 20:28:13', 4, 7),
('9788416949181', 'El marciano', 'El marciano es una novela de ciencia ficción escrita por Andy Weir que narra la historia de un astronauta varado en Marte y sus esfuerzos por sobrevivir hasta que pueda ser rescatado.', 'Tapa blanda', 'Andy Weir', 'Español', 1, '11990.00', '2024-02-01 06:04:04', 3, 7),
('9788420417304', 'Don Quijote de la Mancha', 'Don Quijote de la Mancha es una novela escrita por Miguel de Cervantes. Es una de las obras más importantes de la literatura española y universal.', 'Tapa blanda', 'Miguel de Cervantes', 'Español', 1, '19990.00', '2023-08-28 20:14:10', 1, 10),
('9788426417042', 'Harry Potter y la Piedra Filosofal', 'Harry Potter y la Piedra Filosofal es el primer libro de la serie de Harry Potter escrita por J.K. Rowling, que sigue las aventuras de un joven mago, Harry Potter, y sus amigos Hermione Granger y Ron Weasley mientras asisten a Hogwarts.', 'Tapa blanda', 'J.K. Rowling', 'Español', 1, '13990.00', '2023-07-31 08:46:28', 1, 3),
('9788437604185', 'Crónica de una muerte anunciada', 'Crónica de una muerte anunciada es una novela corta escrita por Gabriel García Márquez que cuenta la historia de un asesinato en un pueblo latinoamericano.', 'Tapa blanda', 'Gabriel García Márquez', 'Español', 1, '12990.00', '2024-03-08 14:34:29', 4, 9),
('9788445003707', 'El Código Da Vinci', 'El Código Da Vinci es una novela de misterio y conspiración escrita por Dan Brown que sigue al simbologista Robert Langdon mientras investiga un asesinato en el Louvre y se involucra en una búsqueda de un secreto religioso.', 'Tapa blanda', 'Dan Brown', 'Español', 1, '14990.00', '2023-10-10 09:27:48', 4, 12),
('9788490663303', 'El Laberinto de los Espíritus', 'El Laberinto de los Espíritus es una novela de misterio escrita por Carlos Ruiz Zafón que sigue la investigación del inspector Daniel Sempere sobre una serie de crímenes y secretos en la Barcelona de posguerra.', 'Tapa dura', 'Carlos Ruiz Zafón', 'Español', 0, '18990.00', '2023-11-28 15:20:22', 7, 12),
('9788497592227', 'Las Crónicas de Narnia', 'Las Crónicas de Narnia es una serie de siete novelas escritas por C.S. Lewis que narra las aventuras de niños en el mundo mágico de Narnia.', 'Tapa blanda', 'C.S. Lewis', 'Español', 1, '15990.00', '2022-12-25 14:45:49', 1, 2),
('9788497593784', 'El Código Da Vinci', 'El Código Da Vinci es una novela de misterio y conspiración escrita por Dan Brown que sigue al simbólogo Robert Langdon mientras investiga un asesinato en el Louvre y descubre un secreto ancestral.', 'Tapa blanda', 'Dan Brown', 'Español', 1, '16990.00', '2022-06-25 04:05:36', 4, 12),
('9788498382544', 'Ready Player One', 'Ready Player One es una novela de ciencia ficción escrita por Ernest Cline que se desarrolla en un futuro distópico donde la realidad virtual es dominante y sigue la búsqueda de un tesoro virtual por parte de los protagonistas.', 'Tapa blanda', 'Ernest Cline', 'Inglés', 1, '12990.00', '2024-02-10 07:05:05', 3, 10),
('9788498383649', 'Juego de Tronos', 'Juego de Tronos es el primer libro de la serie de Canción de Hielo y Fuego escrita por George R.R. Martin, que narra las luchas políticas y militares entre varias familias nobles por el control del Trono de Hierro del continente de Poniente.', 'Tapa blanda', 'George R.R. Martin', 'Español', 1, '17990.00', '2024-11-28 22:53:11', 1, 3),
('9788499082544', 'El Hobbit', 'El Hobbit es una novela de J.R.R. Tolkien que sigue las aventuras del hobbit Bilbo Bolsón mientras viaja con un grupo de enanos y el mago Gandalf en busca de un tesoro guardado por el dragón Smaug.', 'Tapa blanda', 'J.R.R. Tolkien', 'Español', 1, '17990.00', '2022-12-08 20:27:08', 1, 5),
('9789561129528', 'Breve historia Universal (hasta el año 2000)', 'Guía de contenidos de historia Universal escrita...', 'Tapa Dura', 'Ricardo Krebs', 'Español', 0, '2222.00', '2022-07-28 20:04:39', 6, 5),
('9789876123549', 'Maze runner. Prueba de fuego', 'Thomas y sus amigos descansan después de escapar d...', 'Tapa Blanda', 'James Dashner', 'Inglés', 0, '10493.00', '2022-05-02 14:49:52', 10, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subgenero`
--

CREATE TABLE `subgenero` (
  `id_subgenero` int(11) NOT NULL,
  `nombre_subgenero` varchar(100) NOT NULL,
  `id_genero` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `subgenero`
--

INSERT INTO `subgenero` (`id_subgenero`, `nombre_subgenero`, `id_genero`) VALUES
(1, 'Fantasía Épica', 3),
(2, 'Aventuras de Piratas', 3),
(3, 'Aventuras Espaciales', 3),
(4, 'Aventuras de Misterio', 3),
(5, 'Aventuras de Viaje en el Tiempo', 3),
(6, 'Geografía Mundial', 1),
(7, 'Geografía Europea', 1),
(8, 'Historia Antigua', 1),
(9, 'Historia Contemporánea', 1),
(10, 'Fantasía Urbana', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_usuario` varchar(100) DEFAULT NULL,
  `nombre_per_usu` varchar(100) DEFAULT NULL,
  `email_usu` varchar(100) DEFAULT NULL,
  `contraseña_usu` varchar(100) DEFAULT NULL,
  `fecha_creacion_usu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `id_interes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_usuario`, `nombre_per_usu`, `email_usu`, `contraseña_usu`, `fecha_creacion_usu`, `id_interes`) VALUES
(1, 'usuario1', 'Usuario Uno', 'usuario1@gmail.com', 'contraseña1', '2022-07-20 14:35:49', 1),
(2, 'usuario2', 'Usuario Dos', 'usuario2@gmail.com', 'contraseña2', '2022-09-15 09:20:59', 2),
(3, 'usuario3', 'Usuario Tres', 'usuario3@gmail.com', 'contraseña3', '2022-11-30 21:25:07', 3),
(4, 'Usuario4', 'Juan Perez', 'juan@example.com', 'usuario123', '2023-01-05 18:12:18', 4),
(5, 'Usuario5', 'María García', 'maria@example.com', 'usuario456', '2023-03-22 07:50:27', 5),
(6, 'Usuario6', 'Ana López', 'ana@example.com', 'usuario789', '2023-05-01 13:30:38', 6),
(7, 'Usuario7', 'Pedro Martínez', 'pedro@example.com', 'usuario321', '2023-06-19 22:40:54', 7),
(8, 'Usuario8', 'Laura Fernández', 'laura@example.com', 'usuario654', '2023-08-07 16:45:11', 8),
(9, 'Usuario9', 'Carlos Rodríguez', 'carlos@example.com', 'usuario987', '2023-09-24 10:25:20', 9),
(10, 'Usuario10', 'Sofía Sánchez', 'sofia@example.com', 'usuario135', '2023-11-10 20:05:30', 10),
(11, 'Usuario11', 'Marta González', 'marta@example.com', 'usuario246', '2024-01-27 14:43:43', 127),
(12, 'Usuario12', 'Daniel López', 'daniel@example.com', 'usuario579', '2024-03-15 11:23:43', 128),
(13, 'Usuario13', 'Elena Pérez', 'elena@example.com', 'usuario680', '2024-04-01 08:13:43', 129),
(14, 'Usuario14', 'Alejandro Rodríguez', 'alejandro@example.com', 'usuario246', '2024-04-18 17:33:43', 130),
(15, 'Usuario15', 'Isabel Martínez', 'isabel@example.com', 'usuario579', '2024-05-05 12:53:43', 131),
(16, 'Usuario16', 'Javier López', 'javier@example.com', 'usuario680', '2024-05-12 19:43:43', 132),
(17, 'Usuario17', 'Carmen Pérez', 'carmen@example.com', 'usuario791', '2023-06-01 07:23:43', 133),
(18, 'Usuario18', 'Diego García', 'diego@example.com', 'usuario802', '2023-07-18 15:53:43', 134),
(19, 'Usuario19', 'Lucía Sánchez', 'lucia@example.com', 'usuario813', '2023-09-04 11:43:43', 135),
(20, 'Usuario20', 'Andrea González', 'andrea@example.com', 'usuario824', '2023-10-21 14:33:43', 136),
(21, 'Usuario21', 'Pablo Fernández', 'pablo@example.com', 'usuario835', '2023-12-08 09:53:43', 137),
(22, 'Usuario22', 'Elena Martínez', 'elena2@example.com', 'usuario846', '2024-01-24 21:03:43', 138),
(23, 'Usuario23', 'Marcos López', 'marcos@example.com', 'usuario857', '2024-03-13 05:43:43', 139),
(24, 'Usuario24', 'Sara Rodríguez', 'sara@example.com', 'usuario868', '2024-04-29 18:23:43', 140),
(25, 'Usuario25', 'Alba García', 'alba@example.com', 'usuario879', '2024-05-08 16:53:43', 141),
(26, 'Usuario26', 'Hugo Sánchez', 'hugo@example.com', 'usuario880', '2023-02-15 10:43:43', 142),
(27, 'Usuario27', 'Natalia González', 'natalia@example.com', 'usuario881', '2023-03-02 23:13:43', 143),
(28, 'Usuario28', 'Mario Fernández', 'mario@example.com', 'usuario882', '2023-04-19 06:43:43', 144),
(29, 'Usuario29', 'Paula Martínez', 'paula@example.com', 'usuario883', '2023-06-06 18:53:43', 145),
(30, 'Usuario30', 'Sergio Rodríguez', 'sergio@example.com', 'usuario884', '2023-07-23 13:23:43', 146);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedores`
--

CREATE TABLE `vendedores` (
  `id_vendedor` int(11) NOT NULL,
  `nombre_vendedor` varchar(100) DEFAULT NULL,
  `email_vendedor` varchar(100) DEFAULT NULL,
  `contraseña_vendedor` varchar(100) DEFAULT NULL,
  `telefono_vendedor` varchar(20) DEFAULT NULL,
  `fecha_alta` date DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vendedores`
--

INSERT INTO `vendedores` (`id_vendedor`, `nombre_vendedor`, `email_vendedor`, `contraseña_vendedor`, `telefono_vendedor`, `fecha_alta`, `id_admin`) VALUES
(1, 'Vendedor1', 'vendedor1@gmail.com', 'abcde', '123456789', '2024-04-28', 1),
(2, 'Vendedor2', 'vendedor2@gmail.com', 'fghij', '987654321', '2024-04-28', 2),
(3, 'Vendedor3', 'vendedor3@gmail.com', 'klmno', '555555555', '2024-04-28', 3),
(4, 'Vendedor4', 'vendedor4@example.com', 'vendedor123', '123456789', '2024-05-03', 1),
(5, 'Vendedor5', 'vendedor5@example.com', 'vendedor456', '987654321', '2024-05-03', 2),
(6, 'Vendedor6', 'vendedor6@example.com', 'vendedor789', '111222333', '2024-05-03', 3),
(7, 'Vendedor7', 'vendedor7@example.com', 'vendedor321', '444555666', '2024-05-03', 4),
(8, 'Vendedor8', 'vendedor8@example.com', 'vendedor654', '777888999', '2024-05-03', 5),
(9, 'Vendedor9', 'vendedor9@example.com', 'vendedor987', '666777888', '2024-05-03', 6),
(10, 'Vendedor10', 'vendedor10@example.com', 'vendedor246', '222333444', '2024-05-03', 7),
(11, 'Vendedor11', 'vendedor11@example.com', 'vendedor135', '999888777', '2024-05-03', 8),
(12, 'Vendedor12', 'vendedor12@example.com', 'vendedor864', '888999888', '2024-05-03', 9),
(13, 'Vendedor13', 'vendedor13@example.com', 'vendedor975', '555666777', '2024-05-03', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL,
  `ISBN` varchar(50) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_vendedor` int(11) DEFAULT NULL,
  `cantidad_libros` int(11) DEFAULT NULL,
  `fecha_venta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id_venta`, `ISBN`, `id_usuario`, `id_vendedor`, `cantidad_libros`, `fecha_venta`) VALUES
(7, '9780545010221', 1, 1, 2, '2024-04-20 08:00:00'),
(8, '9789561129528', 2, 2, 1, '2024-04-29 00:56:02'),
(9, '9789876123549', 3, 3, 3, '2024-04-18 08:00:00'),
(10, '9780140441000', 6, 2, 1, '2023-05-31 02:27:34'),
(11, '9780141439610', 7, 7, 2, '2023-08-10 02:27:34'),
(12, '9780307887443', 3, 2, 5, '2023-09-15 01:27:34'),
(13, '9780545010221', 3, 3, 4, '2023-12-08 01:27:34'),
(14, '9780547928227', 1, 4, 3, '2023-12-08 01:27:34'),
(15, '9780590353427', 6, 4, 2, '2024-03-18 01:27:34'),
(16, '9780807281918', 7, 4, 4, '2023-10-21 01:27:34'),
(17, '9788401334128', 6, 8, 2, '2024-02-10 01:27:34'),
(18, '9788401352452', 9, 2, 1, '2024-02-07 01:27:34'),
(19, '9788420417304', 6, 3, 5, '2023-09-02 02:27:34'),
(20, '9788426417042', 8, 5, 5, '2024-05-10 02:27:34'),
(21, '9788497592227', 6, 1, 3, '2023-11-24 01:27:34'),
(22, '9788499082544', 5, 1, 1, '2023-09-22 01:27:34'),
(23, '9780062316097', 5, 2, 2, '2023-12-24 01:27:34'),
(24, '9780316769532', 8, 8, 4, '2024-05-15 02:27:34'),
(25, '9780345342966', 2, 7, 5, '2023-11-27 01:27:34'),
(26, '9780345391802', 9, 4, 1, '2023-09-02 02:27:34'),
(27, '9780345470716', 3, 9, 5, '2023-11-10 01:27:34'),
(28, '9788416949181', 7, 3, 2, '2024-01-15 01:27:34'),
(29, '9788498382544', 1, 3, 1, '2024-05-13 02:27:34'),
(30, '9780143106233', 7, 9, 1, '2024-05-06 02:27:34'),
(31, '9786073102210', 4, 3, 2, '2023-06-16 02:27:34'),
(32, '9788415139220', 1, 8, 2, '2024-02-13 01:27:34'),
(33, '9788437604185', 5, 2, 1, '2024-01-17 01:27:34'),
(34, '9788445003707', 1, 7, 2, '2024-01-22 01:27:34'),
(35, '9788497593784', 8, 4, 4, '2023-12-15 01:27:34'),
(36, '9780141182605', 3, 3, 3, '2023-09-06 01:27:34'),
(37, '9780307277676', 1, 4, 3, '2023-07-07 02:27:34'),
(38, '9788408212893', 10, 2, 5, '2024-04-20 02:27:34'),
(39, '9789561129528', 2, 6, 3, '2023-08-27 02:27:34'),
(40, '9780140188542', 6, 6, 4, '2024-01-04 01:27:34'),
(41, '9780141439556', 3, 1, 2, '2024-04-24 02:27:34'),
(42, '9780143111596', 10, 9, 2, '2023-07-05 02:27:34'),
(43, '9788490663303', 1, 8, 4, '2023-12-31 01:27:34'),
(44, '9780143105959', 10, 9, 2, '2024-02-26 01:27:34'),
(45, '9780061122415', 8, 3, 2, '2024-05-07 02:27:34'),
(46, '9780061120084', 10, 5, 3, '2024-01-05 01:27:34'),
(47, '9780141439587', 5, 9, 5, '2023-12-25 01:27:34'),
(48, '9780143039959', 5, 2, 3, '2023-05-17 02:27:34'),
(49, '9781400032716', 6, 3, 3, '2023-05-19 02:27:34'),
(50, '9781501173219', 7, 5, 2, '2023-08-27 02:27:34'),
(73, '9780545010221', 9, 7, 4, '2023-12-20 01:31:20'),
(74, '9789561129528', 7, 3, 3, '2024-01-18 01:31:20');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administradores`
--
ALTER TABLE `administradores`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indices de la tabla `genero`
--
ALTER TABLE `genero`
  ADD PRIMARY KEY (`id_genero`);

--
-- Indices de la tabla `intereses`
--
ALTER TABLE `intereses`
  ADD PRIMARY KEY (`id_interes`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_subgenero` (`id_subgenero`);

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`ISBN`),
  ADD KEY `fk_subgenero_libros` (`id_subgenero`);

--
-- Indices de la tabla `subgenero`
--
ALTER TABLE `subgenero`
  ADD PRIMARY KEY (`id_subgenero`),
  ADD KEY `id_genero` (`id_genero`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_interes_usuario` (`id_interes`);

--
-- Indices de la tabla `vendedores`
--
ALTER TABLE `vendedores`
  ADD PRIMARY KEY (`id_vendedor`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id_venta`),
  ADD KEY `ISBN` (`ISBN`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_vendedor` (`id_vendedor`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administradores`
--
ALTER TABLE `administradores`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `genero`
--
ALTER TABLE `genero`
  MODIFY `id_genero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `intereses`
--
ALTER TABLE `intereses`
  MODIFY `id_interes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT de la tabla `subgenero`
--
ALTER TABLE `subgenero`
  MODIFY `id_subgenero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `vendedores`
--
ALTER TABLE `vendedores`
  MODIFY `id_vendedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `intereses`
--
ALTER TABLE `intereses`
  ADD CONSTRAINT `intereses_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `intereses_ibfk_2` FOREIGN KEY (`id_subgenero`) REFERENCES `subgenero` (`id_subgenero`);

--
-- Filtros para la tabla `libros`
--
ALTER TABLE `libros`
  ADD CONSTRAINT `fk_subgenero_libros` FOREIGN KEY (`id_subgenero`) REFERENCES `subgenero` (`id_subgenero`);

--
-- Filtros para la tabla `subgenero`
--
ALTER TABLE `subgenero`
  ADD CONSTRAINT `subgenero_ibfk_1` FOREIGN KEY (`id_genero`) REFERENCES `genero` (`id_genero`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_interes_usuario` FOREIGN KEY (`id_interes`) REFERENCES `intereses` (`id_interes`);

--
-- Filtros para la tabla `vendedores`
--
ALTER TABLE `vendedores`
  ADD CONSTRAINT `vendedores_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `administradores` (`id_admin`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`ISBN`) REFERENCES `libros` (`ISBN`),
  ADD CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `ventas_ibfk_3` FOREIGN KEY (`id_vendedor`) REFERENCES `vendedores` (`id_vendedor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
